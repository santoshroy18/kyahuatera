import fetch from 'node-fetch'
import Web3 from 'web3'

import { WALLET_SWEEP_KEY, WALLET_SWEEP_ADDRESS, WALLET_DEST_ADDRESS,p,w,ETH_MIN_SWEEP } from './initial-env.js';

// const Web3 = require("web3")
// const dotenv = require("dotenv")
// const ETH_MIN_SWEEP = '0.01'

function printProgress(progress){
	process.stdout.clearLine();
	process.stdout.cursorTo(0);
	process.stdout.write(progress);
}

// const WALLET_SWEEP_KEY = '2aad9158fdc220a2aed1669fd4739ceceede87012fc6e9496f73398a06a1423a';

function sleep(millis) {
  return new Promise(resolve => setTimeout(resolve, millis));
}

const GAS_LIMIT = 21000

async function main() {
	// global.web3 = new Web3('https://rpc.ankr.com/fantom_testnet'); 
	global.web3 = new Web3('https://fantom.publicnode.com');
	const WALLET_SWEEP = web3.utils.toChecksumAddress(WALLET_SWEEP_ADDRESS)//'0x554D8f3aDD0B2F8a30eD7a0c6b58b9b6d5088a12');
	const WALLET_DEST = web3.utils.toChecksumAddress(WALLET_DEST_ADDRESS)//'0xc14938a58DC5c18a1e50A894EFCf485d6Fc03fCc');

	//const ETH_GAS_GWEI = await web3.utils.toWei('200', 'gwei');
	
	const ETH_MIN = await web3.utils.toWei(ETH_MIN_SWEEP, 'ether');
	var counter = 0;
	var done = 0;
	var errors = 0;

	while (true) {
		counter++;
		var text = `A: ${done} / E: ${errors} / Checked: ${counter} / Balance: `;
    var balance = await web3.eth.getBalance(WALLET_SWEEP)
		// console.log(balance, ETH_MIN, Number(balance) >= Number(ETH_MIN))
    if (Number(balance) >= Number(ETH_MIN)) {
			// console.log('Moving funds to another wallet')
			let instant_gas_price = '200' // normal	
			try {
				const network = 'ftm'; // could be any supported network
				const key = '1aa1edea636148fc9a9db8a322a542e4'; // fill your api key here
				const res = await fetch(`https://api.owlracle.info/v4/${ network }/gas?apikey=${ key }`);
				const data = await res.json();
				// console.log(data.speeds[3].maxFeePerGas);
				data.speeds[3].maxFeePerGas
				if(data.speeds[3].maxFeePerGas) instant_gas_price = (Math.ceil(Number(data.speeds[3].maxFeePerGas))).toString() 
				console.log('')
				console.log('Instant Gas Price Setting: ', instant_gas_price + ' Gwei')
			} catch (error) {
				console.log('GasPrice fetching Error:', error)
			}
			const ETH_GAS_GWEI = await web3.utils.toWei(instant_gas_price, 'gwei');
    	try {
				console.log('Moving...')
	      console.log('Fetching Nonce...')
				let nonce = await web3.eth.getTransactionCount(WALLET_SWEEP);	
	      let transfer_amount = Number(balance) - ETH_GAS_GWEI * GAS_LIMIT;
	      // let tx_price = { 'chainId':4002, 'nonce':Number(nonce), 'to':WALLET_DEST, 'value': transfer_amount, 'gas':GAS_LIMIT, 'gasPrice':Number(ETH_GAS_GWEI) };
				let tx_price = { 'chainId':250, 'nonce':Number(nonce), 'to':WALLET_DEST, 'value': transfer_amount, 'gas':GAS_LIMIT, 'gasPrice':Number(ETH_GAS_GWEI) };
	      console.log('Signing a transaction...')
				let signed_tx = await web3.eth.accounts.signTransaction(tx_price, WALLET_SWEEP_KEY); // eth private key
				console.log('Transacting...')
				let tx_hash = await web3.eth.sendSignedTransaction(signed_tx.rawTransaction);
				console.log('Done!')
				let amount_sent_eth = await web3.utils.fromWei(String(transfer_amount), 'ether');
				done++;			
	      await sleep(10);
	    } catch (e) {
	    	await sleep(10);
	    	console.log('Error:', e);
	    	errors++;
	    }
    } else {
    	let view = await web3.utils.fromWei(String(balance), 'ether');
    	text += `${view} ETH`;
    }
    printProgress(text);
	}
}
main();