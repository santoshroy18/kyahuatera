#!/bin/bash
tmux new-session -d -s my_sessionsanty 'node index.js'
